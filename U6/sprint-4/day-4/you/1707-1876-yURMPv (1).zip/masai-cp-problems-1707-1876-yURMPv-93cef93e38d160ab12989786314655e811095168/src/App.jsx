import "./App.css";

function App() {
  return (
    <div data-testid="car-rental-app">
      {/* All the Routes should be visible here  */}
    </div>
  );
}

export default App;
