import React from "react";

function Home() {
  return <div id="car-container">{/* Show all the Car Cards here  */}</div>;
}

export default Home;
