import React from "react";

function Add() {
  return <div>{/* Create the Form here  */}</div>;
}

export default Add;
